# OpenCode for Acode

A sidebar chat panel that talks to an OpenCode agent server over HTTP.

## Features

- 💬 **Chat with AI** — send messages and get coding help
- ⚡ **Streaming responses** — text appears as the AI generates it (via SSE)
- 🎨 **Markdown rendering** — bold, italic, headers, lists, links
- 🔤 **Syntax highlighting** — code blocks with language-aware highlighting (JS, TS, Python, HTML, CSS, Go, Rust, Bash, JSON)
- 📜 **Chat history** — messages persist across sidebar opens
- ⏹️ **Stop generation** — cancel in-flight responses
- 📋 **Insert into editor** — paste AI responses at your cursor

## Setup

1. Run an OpenCode server reachable from your phone (Termux + proot-distro Ubuntu, or a remote box), inside your project folder:
   ```
   opencode serve --hostname 0.0.0.0 --port 4096
   ```
2. Install this plugin in Acode (Settings → Plugins → Local).
3. Open the "OpenCode" icon in Acode's sidebar.
4. Enter the server URL (e.g. `http://192.168.x.x:4096` for local network) and password if set. Tap Save, then Test.
5. Chat. Use "Insert into editor" under any reply to drop that text at your cursor.

## Notes

- The plugin connects to `GET /global/event` for real-time streaming (SSE). If the SSE connection fails, it falls back to non-streaming responses.
- For the server API spec, open `http://<host>:<port>/doc` in a browser.
