# OpenCode for Acode

A sidebar chat panel that talks to an OpenCode agent server over HTTP.

## Setup

1. Run an OpenCode server reachable from your phone (Termux + proot-distro Ubuntu, or a remote box), inside your project folder:
   ```
   opencode serve --hostname 127.0.0.1 --port 4096
   ```
2. Install this plugin in Acode (Settings → Plugins → Local, or the Remote dev-server option).
3. Open the "OpenCode" icon in Acode's sidebar.
4. Enter the host/port (127.0.0.1 / 4096 if running locally via Termux) and tap Save, then Test.
5. Chat. Use "Insert into editor" under any reply to drop that text at your cursor.

## If requests fail

OpenCode's REST paths can differ slightly by version. Open `http://<host>:<port>/doc` from a browser on the same network to see your server's live API spec, and adjust the paths in `main.js` (`createSession`, `sendPrompt`) if they don't match `/session` and `/session/:id/message`.
