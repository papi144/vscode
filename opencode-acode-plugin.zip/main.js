const PLUGIN_ID = 'com.opencode.acode';
const STORAGE_KEY = 'opencode-plugin-config';
// serverUrl covers both cases: "http://127.0.0.1:4096" for a local Termux/proot
// server, or "https://<name>-4096.app.github.dev" for a forwarded Codespace port.
const DEFAULT_CONFIG = { serverUrl: 'http://127.0.0.1:4096', password: '' };

acode.setPluginInit(PLUGIN_ID, async (baseUrl, $page, cache) => {
  const sideBarApps = acode.require('sideBarApps');
  let sessionId = null;

  // ---------- config ----------
  function getConfig() {
    try {
      return { ...DEFAULT_CONFIG, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') };
    } catch (e) {
      return { ...DEFAULT_CONFIG };
    }
  }

  function saveConfig(cfg) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  }

  function apiBaseUrl() {
    let { serverUrl } = getConfig();
    serverUrl = (serverUrl || '').trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(serverUrl)) serverUrl = 'http://' + serverUrl;
    return serverUrl;
  }

  function authHeaders() {
    const { password } = getConfig();
    if (!password) return {};
    return { Authorization: 'Basic ' + btoa('opencode:' + password) };
  }

  // ---------- API client ----------
  // NOTE: OpenCode's REST API can shift between versions. If any call here
  // 404s, open http://<host>:<port>/doc in a browser on the same network to
  // see the exact live OpenAPI spec for your installed version and adjust
  // the paths below.
  async function apiFetch(path, options = {}) {
    let res;
    try {
      res = await fetch(apiBaseUrl() + path, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders(),
          ...(options.headers || {}),
        },
      });
    } catch (e) {
      throw new Error(`Can't reach ${apiBaseUrl()} — is the server running and reachable? (${e.message})`);
    }
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Server responded ${res.status}: ${text.slice(0, 200) || res.statusText}`);
    }
    return res.json().catch(() => ({}));
  }

  async function checkHealth() {
    return apiFetch('/global/health');
  }

  async function createSession() {
    const session = await apiFetch('/session', { method: 'POST', body: JSON.stringify({}) });
    sessionId = session.id || session.sessionID || session.data?.id;
    if (!sessionId) throw new Error('Server did not return a session id — check /doc for the current session-create response shape.');
    return sessionId;
  }

  async function ensureSession() {
    if (sessionId) return sessionId;
    return createSession();
  }

  async function sendPrompt(text) {
    const id = await ensureSession();
    return apiFetch(`/session/${id}/message`, {
      method: 'POST',
      body: JSON.stringify({ parts: [{ type: 'text', text }] }),
    });
  }

  function extractText(message) {
    if (!message) return '';
    if (typeof message === 'string') return message;
    if (Array.isArray(message.parts)) {
      return message.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n');
    }
    if (message.data && Array.isArray(message.data.parts)) {
      return message.data.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n');
    }
    if (message.content) return message.content;
    return JSON.stringify(message);
  }

  // ---------- UI ----------
  sideBarApps.add(
    'icon file_type_ai', // fallback: Acode uses default icon if class isn't found
    'opencode-chat',
    'OpenCode',
    (container) => {
      container.classList.add('opencode-sidebar', 'scroll');
      container.innerHTML = `
        <style>
          .opencode-sidebar { display:flex; flex-direction:column; height:100%; padding:8px; box-sizing:border-box; max-height:100%; overflow-y:auto; }
          .opencode-config { display:flex; flex-direction:column; gap:6px; margin-bottom:10px; }
          .opencode-config input { padding:6px; border-radius:4px; border:1px solid #888; background:transparent; color:inherit; font-size:13px; }
          .opencode-config-row { display:flex; gap:6px; }
          .opencode-config-row input { flex:1; }
          .opencode-status { font-size:12px; opacity:0.8; margin-bottom:6px; min-height:16px; }
          .opencode-messages { flex:1; overflow-y:auto; margin-bottom:8px; }
          .opencode-msg { margin-bottom:10px; padding:8px; border-radius:6px; white-space:pre-wrap; font-size:13px; word-break:break-word; }
          .opencode-msg.user { background:rgba(100,150,255,0.15); }
          .opencode-msg.assistant { background:rgba(120,120,120,0.15); }
          .opencode-msg .insert-btn { display:inline-block; margin-top:6px; font-size:11px; padding:2px 8px; border:1px solid currentColor; border-radius:4px; cursor:pointer; opacity:0.8; }
          .opencode-input-row { display:flex; gap:6px; }
          .opencode-input-row textarea { flex:1; min-height:44px; padding:6px; border-radius:4px; border:1px solid #888; background:transparent; color:inherit; resize:vertical; font-size:13px; }
          .opencode-btn { padding:6px 10px; border-radius:4px; border:1px solid #888; background:transparent; color:inherit; cursor:pointer; font-size:12px; }
          .opencode-btn:active { opacity:0.6; }
        </style>
        <div class="opencode-config">
          <input type="text" id="oc-url" placeholder="Server URL (http://127.0.0.1:4096)" />
          <input type="password" id="oc-password" placeholder="Password (optional)" />
          <div class="opencode-config-row">
            <button class="opencode-btn" id="oc-save">Save</button>
            <button class="opencode-btn" id="oc-test">Test</button>
            <button class="opencode-btn" id="oc-new">New session</button>
          </div>
          <div class="opencode-status" id="oc-status">Not connected</div>
        </div>
        <div class="opencode-messages" id="oc-messages"></div>
        <div class="opencode-input-row">
          <textarea id="oc-input" placeholder="Ask OpenCode..."></textarea>
          <button class="opencode-btn" id="oc-send">Send</button>
        </div>
      `;

      const $url = container.querySelector('#oc-url');
      const $password = container.querySelector('#oc-password');
      const $status = container.querySelector('#oc-status');
      const $messages = container.querySelector('#oc-messages');
      const $input = container.querySelector('#oc-input');
      const $send = container.querySelector('#oc-send');

      const cfg = getConfig();
      $url.value = cfg.serverUrl;
      $password.value = cfg.password;

      function setStatus(text, isError) {
        $status.textContent = text;
        $status.style.color = isError ? '#e05555' : '';
      }

      function addMessage(role, text) {
        const el = document.createElement('div');
        el.className = `opencode-msg ${role}`;
        el.textContent = text;
        if (role === 'assistant' && text) {
          const insertBtn = document.createElement('div');
          insertBtn.className = 'insert-btn';
          insertBtn.textContent = 'Insert into editor';
          insertBtn.onclick = () => {
            const editor = editorManager.editor;
            editor.session.insert(editor.getCursorPosition(), text);
            if (window.toast) window.toast('Inserted', 1500);
          };
          el.appendChild(insertBtn);
        }
        $messages.appendChild(el);
        $messages.scrollTop = $messages.scrollHeight;
      }

      container.querySelector('#oc-save').onclick = () => {
        saveConfig({
          serverUrl: $url.value.trim() || DEFAULT_CONFIG.serverUrl,
          password: $password.value,
        });
        sessionId = null;
        setStatus('Saved. Tap "Test" to verify the connection.');
      };

      container.querySelector('#oc-test').onclick = async () => {
        setStatus('Checking...');
        try {
          const health = await checkHealth();
          setStatus(`Connected — server v${health.version || health.data?.version || '?'}`);
        } catch (e) {
          setStatus(e.message, true);
        }
      };

      container.querySelector('#oc-new').onclick = async () => {
        try {
          setStatus('Starting new session...');
          sessionId = null;
          await createSession();
          $messages.innerHTML = '';
          setStatus('New session started.');
        } catch (e) {
          setStatus(e.message, true);
        }
      };

      async function send() {
        const text = $input.value.trim();
        if (!text) return;
        $input.value = '';
        $send.disabled = true;
        addMessage('user', text);
        setStatus('Thinking...');
        try {
          const resp = await sendPrompt(text);
          const reply = extractText(resp);
          addMessage('assistant', reply || '(empty response — check /doc for this server\u2019s message response shape)');
          setStatus('Ready');
        } catch (e) {
          setStatus(e.message, true);
          addMessage('assistant', `Error: ${e.message}`);
        } finally {
          $send.disabled = false;
        }
      }

      $send.onclick = send;
      $input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          send();
        }
      });
    },
    false
  );
});

acode.setPluginUnmount(PLUGIN_ID, () => {
  const sideBarApps = acode.require('sideBarApps');
  sideBarApps.remove('opencode-chat');
});
