const PLUGIN_ID = 'com.opencode.acode';
const STORAGE_KEY = 'opencode-plugin-config';
const HISTORY_KEY = 'opencode-plugin-history';
const DEFAULT_CONFIG = { serverUrl: 'http://127.0.0.1:4096', password: '' };

acode.setPluginInit(PLUGIN_ID, async (baseUrl, $page, cache) => {
  const sideBarApps = acode.require('sideBarApps');
  let sessionId = null;
  let isStreaming = false;
  let abortController = null;
  let sseAbortController = null;
  let sseReader = null;
  let pendingMsgId = null;
  let messageContents = {};

  // ---------- config ----------
  function getConfig() {
    try {
      return { ...DEFAULT_CONFIG, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') };
    } catch { return { ...DEFAULT_CONFIG }; }
  }
  function saveConfig(cfg) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  }
  function apiBaseUrl() {
    let { serverUrl } = getConfig();
    serverUrl = (serverUrl || '').trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(serverUrl)) serverUrl = 'http://' + serverUrl;
    return serverUrl;
  }
  function authHeaders() {
    const { password } = getConfig();
    if (!password) return {};
    return { Authorization: 'Basic ' + btoa('opencode:' + password) };
  }

  // ---------- history ----------
  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); } catch { return []; }
  }
  function saveHistory(msgs) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(msgs));
  }

  // ---------- API client ----------
  async function apiFetch(path, options = {}) {
    let res;
    try {
      res = await fetch(apiBaseUrl() + path, {
        ...options,
        headers: { 'Content-Type': 'application/json', ...authHeaders(), ...(options.headers || {}) },
      });
    } catch (e) {
      throw new Error(`Can't reach ${apiBaseUrl()} — is the server running? (${e.message})`);
    }
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Server responded ${res.status}: ${text.slice(0, 200) || res.statusText}`);
    }
    return res.json().catch(() => ({}));
  }

  async function checkHealth() {
    return apiFetch('/global/health');
  }
  async function createSession() {
    const session = await apiFetch('/session', { method: 'POST', body: JSON.stringify({}) });
    sessionId = session.id || session.sessionID || session.data?.id;
    if (!sessionId) throw new Error('Server did not return a session id');
    return sessionId;
  }
  async function ensureSession() {
    if (sessionId) return sessionId;
    return createSession();
  }

  // ---------- SSE streaming ----------
  function connectSSE(onEvent) {
    if (sseAbortController) sseAbortController.abort();
    sseAbortController = new AbortController();
    const headers = authHeaders();

    (async () => {
      try {
        const res = await fetch(apiBaseUrl() + '/global/event', {
          headers: { ...headers, Accept: 'text/event-stream' },
          signal: sseAbortController.signal,
        });
        if (!res.ok || !res.body) return;
        sseReader = res.body.getReader();
        const decoder = new TextDecoder();
        let buf = '';
        let evtType = '';

        while (true) {
          const { done, value } = await sseReader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const lines = buf.split('\n');
          buf = lines.pop() || '';
          for (const line of lines) {
            if (line.startsWith('event: ')) {
              evtType = line.slice(7).trim();
            } else if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6));
                onEvent(evtType, data);
              } catch {}
            } else if (line === '') {
              evtType = '';
            }
          }
        }
      } catch {}
    })();
  }

  function disconnectSSE() {
    if (sseAbortController) {
      sseAbortController.abort();
      sseAbortController = null;
      sseReader = null;
    }
  }

  // ---------- markdown renderer ----------
  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function highlightCode(code, lang) {
    const map = {
      js: /\b(const|let|var|function|return|if|else|for|while|of|in|do|switch|case|break|continue|class|import|export|default|from|async|await|new|this|throw|try|catch|finally|typeof|instanceof|yield|super|static|get|set|extends|true|false|null|undefined|NaN)\b/g,
      javascript: /\b(const|let|var|function|return|if|else|for|while|of|in|do|switch|case|break|continue|class|import|export|default|from|async|await|new|this|throw|try|catch|finally|typeof|instanceof|yield|super|static|get|set|extends|true|false|null|undefined|NaN)\b/g,
      ts: /\b(const|let|var|function|return|if|else|for|while|of|in|do|switch|case|break|continue|class|import|export|default|from|async|await|new|this|throw|try|catch|finally|interface|type|enum|implements|extends|abstract|private|protected|public|readonly|static|get|set|true|false|null|undefined|any|void|never|unknown)\b/g,
      typescript: /\b(const|let|var|function|return|if|else|for|while|of|in|do|switch|case|break|continue|class|import|export|default|from|async|await|new|this|throw|try|catch|finally|interface|type|enum|implements|extends|abstract|private|protected|public|readonly|static|get|set|true|false|null|undefined|any|void|never|unknown)\b/g,
      py: /\b(def|class|return|if|elif|else|for|while|import|from|as|try|except|finally|with|yield|async|await|lambda|pass|raise|self|True|False|None|and|or|not|is|in|del|global|nonlocal|break|continue|assert|print)\b/g,
      python: /\b(def|class|return|if|elif|else|for|while|import|from|as|try|except|finally|with|yield|async|await|lambda|pass|raise|self|True|False|None|and|or|not|is|in|del|global|nonlocal|break|continue|assert|print)\b/g,
      html: /(&lt;\/?[\w-]+)/g,
      css: /\b(color|background|margin|padding|border|display|flex|grid|font-size|width|height|position|top|left|right|bottom|text-align|font-weight|font-family|overflow|z-index|opacity|transform|transition|animation|box-shadow|text-shadow|border-radius|important)\b/g,
      json: /("(?:[^"\\]|\\.)*")\s*:/g,
      bash: /\b(if|then|else|fi|for|while|do|done|case|esac|function|return|local|export|echo|exit|cd|ls|rm|mv|cp|mkdir|touch|cat|grep|sed|awk|chmod|chown|sudo|apt|npm|yarn|pip|docker|git|curl|wget)\b/g,
      sh: /\b(if|then|else|fi|for|while|do|done|case|esac|function|return|local|export|echo|exit|cd|ls|rm|mv|cp|mkdir|touch|cat|grep|sed|awk|chmod|chown|sudo|apt|npm|yarn|pip|docker|git|curl|wget)\b/g,
      go: /\b(func|return|if|else|for|range|switch|case|break|continue|defer|go|select|struct|interface|map|chan|type|package|import|var|const|true|false|nil|make|new|append|len|cap|error|string|int|bool|float64)\b/g,
      rust: /\b(fn|let|mut|return|if|else|for|while|loop|match|break|continue|struct|enum|impl|trait|pub|use|mod|crate|self|super|true|false|Some|None|Ok|Err|as|ref|move|async|await|unsafe)\b/g,
    };
    const escaped = escapeHtml(code);
    const pattern = map[lang];
    if (!pattern) return escaped;
    return escaped.replace(pattern, '<span class="hl">$1</span>');
  }

  function renderMarkdown(text) {
    if (!text) return '';

    // Extract and replace code blocks first
    const blocks = [];
    let idx = 0;
    let processed = text.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
      const id = `%%CB${idx}%%`;
      blocks.push({ id, html: `<pre><code class="lang-${lang}">${highlightCode(code, lang)}</code></pre>` });
      idx++;
      return id;
    });

    let html = escapeHtml(processed);

    // Restore code blocks
    for (const b of blocks) {
      html = html.replace(b.id, b.html);
    }

    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Bold & italic
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

    // Links
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

    // Headers
    html = html.replace(/^#### (.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

    // Lists
    html = html.replace(/^- (.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');
    html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

    // Wrap consecutive non-list, non-header, non-empty lines in paragraphs
    const paraLines = html.split('\n');
    let result = '';
    let inPara = false;
    let paraContent = '';
    for (const line of paraLines) {
      const trimmed = line.trim();
      if (!trimmed) {
        if (inPara) {
          result += `<p>${paraContent.trim()}</p>`;
          paraContent = '';
          inPara = false;
        }
        continue;
      }
      if (trimmed.startsWith('<h') || trimmed.startsWith('<ul') || trimmed.startsWith('<ol') || trimmed.startsWith('<pre') || trimmed.startsWith('<li') || trimmed.startsWith('</')) {
        if (inPara) {
          result += `<p>${paraContent.trim()}</p>`;
          paraContent = '';
          inPara = false;
        }
        result += line + '\n';
      } else {
        if (inPara) paraContent += ' ' + trimmed;
        else { paraContent = trimmed; inPara = true; }
      }
    }
    if (inPara) result += `<p>${paraContent.trim()}</p>`;

    return result.replace(/\n{2,}/g, '\n').trim();
  }

  // ---------- UI ----------
  sideBarApps.add(
    'icon file_type_ai',
    'opencode-chat',
    'OpenCode',
    (container) => {
      container.classList.add('opencode-sidebar', 'scroll');
      container.innerHTML = `
        <style>
          .opencode-sidebar { display:flex; flex-direction:column; height:100%; padding:8px; box-sizing:border-box; max-height:100%; overflow-y:auto; }
          .opencode-config { display:flex; flex-direction:column; gap:6px; margin-bottom:10px; }
          .opencode-config input { padding:6px; border-radius:4px; border:1px solid #888; background:transparent; color:inherit; font-size:13px; }
          .opencode-config-row { display:flex; gap:6px; }
          .opencode-config-row input { flex:1; }
          .opencode-status { font-size:12px; opacity:0.8; margin-bottom:6px; min-height:16px; }
          .opencode-messages { flex:1; overflow-y:auto; margin-bottom:8px; }
          .opencode-msg { margin-bottom:10px; padding:8px 10px; border-radius:6px; font-size:13px; word-break:break-word; line-height:1.5; }
          .opencode-msg p { margin:4px 0; }
          .opencode-msg p:first-child { margin-top:0; }
          .opencode-msg p:last-child { margin-bottom:0; }
          .opencode-msg ul, .opencode-msg ol { margin:4px 0; padding-left:20px; }
          .opencode-msg li { margin:2px 0; }
          .opencode-msg h1, .opencode-msg h2, .opencode-msg h3, .opencode-msg h4 { margin:8px 0 4px; font-weight:600; }
          .opencode-msg h1 { font-size:16px; }
          .opencode-msg h2 { font-size:15px; }
          .opencode-msg h3 { font-size:14px; }
          .opencode-msg h4 { font-size:13px; }
          .opencode-msg pre { margin:6px 0; padding:8px; border-radius:4px; background:rgba(0,0,0,0.08); overflow-x:auto; font-size:12px; }
          .opencode-msg code { padding:1px 4px; border-radius:3px; background:rgba(0,0,0,0.08); font-size:12px; }
          .opencode-msg pre code { padding:0; background:none; }
          .opencode-msg .hl { color:#569cd6; font-weight:600; }
          .opencode-msg a { color:#4a9eff; text-decoration:underline; }
          .opencode-msg.user { background:rgba(100,150,255,0.15); }
          .opencode-msg.assistant { background:rgba(120,120,120,0.12); }
          .opencode-msg .insert-btn { display:inline-block; margin-top:6px; font-size:11px; padding:2px 8px; border:1px solid currentColor; border-radius:4px; cursor:pointer; opacity:0.8; }
          .opencode-input-row { display:flex; gap:6px; align-items:flex-end; }
          .opencode-input-row textarea { flex:1; min-height:44px; max-height:120px; padding:6px; border-radius:4px; border:1px solid #888; background:transparent; color:inherit; resize:none; font-size:13px; }
          .opencode-btn { padding:6px 10px; border-radius:4px; border:1px solid #888; background:transparent; color:inherit; cursor:pointer; font-size:12px; white-space:nowrap; }
          .opencode-btn:active { opacity:0.6; }
          .opencode-btn:disabled { opacity:0.4; cursor:default; }
          .opencode-btn.danger { color:#e05555; border-color:#e05555; }
          .opencode-loading { display:inline-block; width:12px; height:12px; border:2px solid rgba(128,128,128,0.3); border-top-color:currentColor; border-radius:50%; animation:oc-spin .6s linear infinite; vertical-align:middle; margin-right:4px; }
          @keyframes oc-spin { to { transform:rotate(360deg); } }
          .opencode-cancel-row { display:flex; gap:6px; margin-top:4px; }
          .opencode-cancel-row .opencode-btn { flex:1; }
        </style>
        <div class="opencode-config">
          <input type="text" id="oc-url" placeholder="Server URL (http://127.0.0.1:4096)" />
          <input type="password" id="oc-password" placeholder="Password (optional)" />
          <div class="opencode-config-row">
            <button class="opencode-btn" id="oc-save">Save</button>
            <button class="opencode-btn" id="oc-test">Test</button>
            <button class="opencode-btn" id="oc-new">New session</button>
          </div>
          <div class="opencode-status" id="oc-status">Not connected</div>
        </div>
        <div class="opencode-messages" id="oc-messages"></div>
        <div class="opencode-cancel-row" id="oc-cancel-row" style="display:none">
          <button class="opencode-btn danger" id="oc-cancel">Stop generation</button>
        </div>
        <div class="opencode-input-row">
          <textarea id="oc-input" placeholder="Ask OpenCode…" rows="1"></textarea>
          <button class="opencode-btn" id="oc-send">Send</button>
        </div>
      `;

      const $url = container.querySelector('#oc-url');
      const $password = container.querySelector('#oc-password');
      const $status = container.querySelector('#oc-status');
      const $messages = container.querySelector('#oc-messages');
      const $input = container.querySelector('#oc-input');
      const $send = container.querySelector('#oc-send');
      const $cancelRow = container.querySelector('#oc-cancel-row');
      const $cancel = container.querySelector('#oc-cancel');

      let history = loadHistory();

      // Apply saved config
      const cfg = getConfig();
      $url.value = cfg.serverUrl;
      $password.value = cfg.password;

      function setStatus(text, isError) {
        $status.textContent = text;
        $status.style.color = isError ? '#e05555' : '';
      }

      function getRawText(text) {
        if (!text) return '';
        // Strip HTML for insert-into-editor
        const d = document.createElement('div');
        d.innerHTML = text;
        return d.textContent || d.innerText || '';
      }

      function addMessage(role, text, id) {
        const el = document.createElement('div');
        el.className = `opencode-msg ${role}`;
        if (id) el.dataset.msgId = id;

        if (role === 'assistant') {
          el.innerHTML = renderMarkdown(text) || '(empty response)';
          if (text) {
            const insertBtn = document.createElement('div');
            insertBtn.className = 'insert-btn';
            insertBtn.textContent = 'Insert into editor';
            insertBtn.onclick = () => {
              const raw = getRawText(text);
              const editor = editorManager.editor;
              editor.session.insert(editor.getCursorPosition(), raw);
              if (window.toast) window.toast('Inserted', 1500);
            };
            el.appendChild(insertBtn);
          }
        } else {
          el.textContent = text;
        }

        $messages.appendChild(el);
        $messages.scrollTop = $messages.scrollHeight;
        return el;
      }

      function updateMessage(el, text) {
        if (!el) return;
        const insert = el.querySelector('.insert-btn');
        el.innerHTML = renderMarkdown(text) || '(empty response)';
        if (text) {
          if (!insert) {
            const insertBtn = document.createElement('div');
            insertBtn.className = 'insert-btn';
            insertBtn.textContent = 'Insert into editor';
            insertBtn.onclick = () => {
              const raw = getRawText(text);
              const editor = editorManager.editor;
              editor.session.insert(editor.getCursorPosition(), raw);
              if (window.toast) window.toast('Inserted', 1500);
            };
            el.appendChild(insertBtn);
          } else {
            el.appendChild(insert);
          }
        }
        $messages.scrollTop = $messages.scrollHeight;
      }

      function saveCurrentHistory() {
        const msgs = [];
        $messages.querySelectorAll('.opencode-msg').forEach((el) => {
          const role = el.classList.contains('user') ? 'user' : 'assistant';
          const raw = getRawText(el.innerHTML);
          msgs.push({ role, text: raw });
        });
        saveHistory(msgs);
      }

      function restoreHistory() {
        $messages.innerHTML = '';
        for (const msg of history) {
          addMessage(msg.role, msg.text);
        }
      }

      function setStreaming(streaming) {
        isStreaming = streaming;
        $cancelRow.style.display = streaming ? 'flex' : 'none';
        $send.disabled = streaming;
        $input.disabled = streaming;
      }

      // Restore history
      restoreHistory();

      // Connect SSE
      connectSSE((eventType, data) => {
        if (eventType === 'message.part.updated') {
          const props = data.properties || {};
          const part = props.part || {};
          const delta = props.delta || '';
          const msgId = part.messageID || part.id;
          const sId = part.sessionID || part.sessionId;

          if (!msgId || (sessionId && sId && sId !== sessionId)) return;

          if (!messageContents[msgId]) messageContents[msgId] = '';
          messageContents[msgId] += delta;

          const el = $messages.querySelector(`[data-msg-id="${msgId}"]`);
          if (el) {
            updateMessage(el, messageContents[msgId]);
          } else if (msgId === pendingMsgId) {
            const el = addMessage('assistant', messageContents[msgId], msgId);
          }
        } else if (eventType === 'message.updated') {
          const props = data.properties || {};
          const msg = props.message || {};
          const msgId = msg.id || msg.messageID;
          if (msgId && messageContents[msgId]) {
            delete messageContents[msgId];
          }
        }
      });

      // ---- event handlers ----
      container.querySelector('#oc-save').onclick = () => {
        saveConfig({
          serverUrl: $url.value.trim() || DEFAULT_CONFIG.serverUrl,
          password: $password.value,
        });
        sessionId = null;
        setStatus('Saved. Tap "Test" to verify the connection.');
      };

      container.querySelector('#oc-test').onclick = async () => {
        setStatus('Checking…');
        try {
          const health = await checkHealth();
          setStatus(`Connected — server v${health.version || health.data?.version || '?'}`);
        } catch (e) {
          setStatus(e.message, true);
        }
      };

      container.querySelector('#oc-new').onclick = async () => {
        try {
          setStatus('Starting new session…');
          sessionId = null;
          await createSession();
          $messages.innerHTML = '';
          history = [];
          saveHistory([]);
          setStatus('New session started.');
        } catch (e) {
          setStatus(e.message, true);
        }
      };

      $cancel.onclick = () => {
        if (abortController) {
          abortController.abort();
          abortController = null;
        }
        if (isStreaming) {
          setStreaming(false);
          setStatus('Cancelled.');
        }
      };

      async function send() {
        const text = $input.value.trim();
        if (!text || isStreaming) return;
        $input.value = '';
        $input.style.height = 'auto';

        addMessage('user', text);
        setStreaming(true);
        setStatus('Thinking…');

        abortController = new AbortController();
        pendingMsgId = null;

        try {
          const id = await ensureSession();
          const res = await fetch(apiBaseUrl() + `/session/${id}/message`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders() },
            body: JSON.stringify({ parts: [{ type: 'text', text }] }),
            signal: abortController.signal,
          });

          if (!res.ok) {
            const errText = await res.text().catch(() => '');
            throw new Error(`Server responded ${res.status}: ${errText.slice(0, 200) || res.statusText}`);
          }

          const data = await res.json();
          const reply = extractText(data);

          if (reply) {
            const msgId = pendingMsgId || data.info?.id || data.id || data.messageID || Date.now().toString();
            const existing = $messages.querySelector(`[data-msg-id="${msgId}"]`);
            if (existing) {
              updateMessage(existing, reply);
            } else {
              // If no SSE stream built it, add it now
              addMessage('assistant', reply, msgId);
            }
            delete messageContents[msgId];
          }

          setStatus('Ready');
        } catch (e) {
          if (e.name === 'AbortError') {
            setStatus('Cancelled.');
          } else {
            setStatus(e.message, true);
            const last = $messages.lastElementChild;
            if (last && last.classList.contains('assistant') && !getRawText(last.innerHTML).trim()) {
              last.remove();
            }
            addMessage('assistant', `Error: ${e.message}`);
          }
        } finally {
          setStreaming(false);
          abortController = null;
          pendingMsgId = null;
          saveCurrentHistory();
        }
      }

      function extractText(message) {
        if (!message) return '';
        if (typeof message === 'string') return message;
        if (Array.isArray(message.parts)) {
          return message.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n');
        }
        if (message.data && Array.isArray(message.data.parts)) {
          return message.data.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n');
        }
        if (message.content) return message.content;
        if (message.info && Array.isArray(message.parts)) {
          return message.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n');
        }
        if (message.text) return message.text;
        return JSON.stringify(message);
      }

      $send.onclick = send;
      $input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          send();
        }
      });

      // Auto-resize textarea
      $input.addEventListener('input', () => {
        $input.style.height = 'auto';
        $input.style.height = Math.min($input.scrollHeight, 120) + 'px';
      });
    },
    false
  );
});

acode.setPluginUnmount(PLUGIN_ID, () => {
  const sideBarApps = acode.require('sideBarApps');
  sideBarApps.remove('opencode-chat');
});
